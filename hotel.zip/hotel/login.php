<?php 
session_start(); 
require "conexao.php"; 
$login = $_POST['login'] ?? ''; 
$senha = $_POST['senha'] ?? ''; 
$sql = "SELECT * 
FROM usuario 
WHERE login = ?"; 
$stmt = $conn->prepare($sql); 
$stmt->bind_param( 
"s", 
$login 
); 
$stmt->execute(); 
$resultado = 
$stmt->get_result(); 
if($resultado->num_rows == 1){ 
 
    $usuario = 
    $resultado->fetch_assoc(); 
 
    if( 
        password_verify( 
            $senha, 
            $usuario['senha'] 
        ) 
    ){ 
 
        $_SESSION['usuario'] = 
        $usuario['nome']; 
 
        $_SESSION['id_usuario'] = 
        $usuario['id_usuario']; 
 
        $_SESSION['ultimo_acesso'] = 
        time(); 
 
        header( 
            "Location: dashboard.php" 
        ); 
 
        exit; 
 
    } 
 
} 
 
echo " 
<script> 
alert('Usuário ou senha inválidos'); 
window.location='index.php'; 
</script> 
"; 
?>