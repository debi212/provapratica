<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$id = 
intval($_POST['reserva']); 
/* 
Descobrir quarto 
*/ 
$stmt = 
$conn->prepare( 
"SELECT id_quarto 
FROM reserva 
WHERE id_reserva=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
$reserva = 
$stmt->get_result() ->fetch_assoc(); 
$id_quarto = 
$reserva['id_quarto']; 
/* 
Atualizar reserva 
*/ 
$stmt = 
$conn->prepare( 
"UPDATE reserva 
SET status='Hospedado' 
WHERE id_reserva=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
/* 
Atualizar quarto 
*/ 
$stmt = 
$conn->prepare( 
"UPDATE quarto 
SET status='Ocupado' 
WHERE id_quarto=?" 
); 
$stmt->bind_param( 
"i", 
$id_quarto 
); 
$stmt->execute(); 
echo 
"Check-in realizado com sucesso."; 
?> 