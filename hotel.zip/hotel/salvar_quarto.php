<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$numero = 
$_POST['numero']; 
$tipo = 
$_POST['tipo']; 
$capacidade = 
intval($_POST['capacidade']); 
$valor = 
floatval($_POST['valor']); 
$status = 
"Disponível"; 
$stmt = 
$conn->prepare( 
"INSERT INTO quarto 
(numero,tipo,capacidade, 
valor_diaria,status) 
VALUES (?,?,?,?,?)" 
); 
$stmt->bind_param( 
"ssids", 
$numero, 
$tipo, 
$capacidade, 
$valor, 
$status 
); 
$stmt->execute(); 
header( 
"Location: quartos.php" 
); 
?>