<h2>Novo quarto</h2> 
<form 
action="salvar_quarto.php" 
method="POST"> 
Número: 
<input 
name="numero" 
required> 
<br><br> 
Tipo: 
<select name="tipo"> 
<option>Standard</option> 
<option>Luxo</option> 
<option>Suíte</option> 
<option>Executivo</option> 
</select> 
<br><br> 
Capacidade: 
<input 
type="number" 
name="capacidade"> 
<br><br> 
Valor da diária: 
<input 
type="number" 
step="0.01" 
name="valor"> 
<br><br> 
<button> 
Cadastrar 
</button> 
</form>