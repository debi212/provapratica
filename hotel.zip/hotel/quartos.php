<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$resultado = 
$conn->query( 
"SELECT * 
FROM quarto 
ORDER BY numero" 
); 
?> 

<h1>Quartos</h1> 
<a href="novo_quarto.php"> 
Cadastrar quarto 
</a> 
<br><br> 
<table border="1"> 
<tr> 
<th>Quarto</th> 
<th>Tipo</th> 
<th>Capacidade</th> 
<th>Diária</th> 
<th>Status</th> 
</tr> 
<?php 
while( 
$q = 
$resultado->fetch_assoc() 
){ 
?> 
<tr> 
<td><?= $q['numero'] ?></td> 
<td><?= $q['tipo'] ?></td> 
<td><?= $q['capacidade'] ?></td> 
<td> 
R$ 
<?= number_format( 
$q['valor_diaria'], 
2, 
',', 
'.' 
) ?> 
</td> 
<td><?= $q['status'] ?></td> 
</tr> 
<?php } ?> 
</table>