<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$id = 
intval($_GET['id']); 
$stmt = 
$conn->prepare( 
"DELETE FROM hospede 
WHERE id_hospede=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
header( 
"Location: hospedes.php" 
); 
?>