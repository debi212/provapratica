<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$id = 
intval($_POST['id']); 
$nome = 
$_POST['nome']; 
$cpf = 
$_POST['cpf']; 
$telefone = 
$_POST['telefone']; 
$email = 
$_POST['email']; 
$endereco = 
$_POST['endereco']; 
$stmt = 
$conn->prepare( 
"UPDATE hospede 
SET nome=?, 
cpf=?, 
telefone=?, 
email=?, 
endereco=? 
WHERE id_hospede=?" 
); 
$stmt->bind_param( 
"sssssi", 
$nome, 
$cpf, 
$telefone, 
$email, 
$endereco, 
$id 
); 
$stmt->execute(); 
header( 
"Location: hospedes.php" 
); 
?>