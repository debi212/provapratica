relatorio.php 
<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$totalHospedes = 
$conn->query( 
"SELECT COUNT(*) total 
FROM hospede" 
)->fetch_assoc()['total']; 
$totalQuartos = 
$conn->query( 
"SELECT COUNT(*) total 
FROM quarto" 
)->fetch_assoc()['total']; 
$disponiveis = 
$conn->query( 
"SELECT COUNT(*) total 
FROM quarto 
WHERE status='Disponível'" 
)->fetch_assoc()['total']; 
$ocupados = 
$conn->query( 
"SELECT COUNT(*) total 
FROM quarto 
WHERE status='Ocupado'" 
)->fetch_assoc()['total']; 
$reservados = 
$conn->query( 
"SELECT COUNT(*) total 
FROM quarto 
WHERE status='Reservado'" 
)->fetch_assoc()['total']; 
?> 
<h1> 
HotelSys — Relatório 
</h1> 
<p> 
Hóspedes cadastrados: 
<strong> 
<?= $totalHospedes ?> 
</strong> 
</p> 
<p> 
Total de quartos: 
<strong> 
<?= $totalQuartos ?> 
</strong> 
</p> 
<p> 
Disponíveis: 
<strong> 
<?= $disponiveis ?> 
</strong> 
</p> 
<p> 
Ocupados: 
<strong> 
<?= $ocupados ?> 
</strong> 
</p> 
<p> 
Reservados: 
<strong> 
<?= $reservados ?> 
</strong> 
</p>