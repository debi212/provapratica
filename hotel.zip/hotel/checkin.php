<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$reservas = 
$conn->query( 
"SELECT 
r.id_reserva, 
h.nome, 
q.numero 
FROM reserva r 
INNER JOIN hospede h 
ON r.id_hospede = 
h.id_hospede 
INNER JOIN quarto q 
ON r.id_quarto = 
q.id_quarto 
WHERE 
r.status='Reservada'" 
); 
?> 
<h1>Check-in</h1> 
<form 
action="realizar_checkin.php" 
method="POST"> 
Reserva: 
<select name="reserva"> 
<?php 
while( 
$r = 
$reservas->fetch_assoc() 
){ 
?> 
<option 
value="<?= $r['id_reserva'] ?>"> 
<?= $r['nome'] ?> - 
Quarto 
<?= $r['numero'] ?> 
</option> 
<?php } ?> 
</select> 
<button> 
Realizar Check-in 
</button> 
</form>