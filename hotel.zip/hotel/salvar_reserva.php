<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$hospede = 
intval($_POST['hospede']); 
$quarto = 
intval($_POST['quarto']); 
$entrada = 
$_POST['entrada']; 
$saida = 
$_POST['saida']; 
/* 
Verificar disponibilidade 
*/ 
$stmt = 
$conn->prepare( 
"SELECT status 
FROM quarto 
WHERE id_quarto=?" 
); 
$stmt->bind_param( 
"i", 
$quarto 
); 
$stmt->execute(); 
$q = 
$stmt->get_result() ->fetch_assoc(); 
if( 
$q['status'] 
!= 
'Disponível' 
){ 
} 
/* 
die( 
"Quarto indisponível." 
); 
Criar reserva 
*/ 
$stmt = 
$conn->prepare( 
"INSERT INTO reserva 
(id_hospede, 
id_quarto, 
data_entrada, 
data_saida, 
status) 
VALUES 
(?,?,?,?,'Reservada')" 
); 
$stmt->bind_param( 
"iiss", 
$hospede, 
$quarto, 
$entrada, 
$saida 
); 
$stmt->execute(); 
/* 
Alterar quarto 
*/ 
$stmt = 
$conn->prepare( 
"UPDATE quarto 
SET status='Reservado' 
WHERE id_quarto=?" 
); 
$stmt->bind_param( 
"i", 
$quarto 
); 
$stmt->execute(); 
header( 
"Location: reservas.php" 
); 
?>