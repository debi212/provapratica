<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$id = 
intval($_GET['id']); 
$stmt = 
$conn->prepare( 
"SELECT 
r.*, 
q.numero, 
q.valor_diaria 
FROM reserva r 
INNER JOIN quarto q 
ON r.id_quarto = 
q.id_quarto 
WHERE 
r.id_reserva=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
$r = 
$stmt->get_result() ->fetch_assoc(); 
/* 
Calcular dias 
*/ 
$entrada = 
new DateTime( 
$r['data_entrada'] 
); 
$saida = 
new DateTime( 
$r['data_saida'] 
); 
$diferenca = 
$entrada->diff($saida); 
$dias = 
$diferenca->days; 
if($dias < 1){ 
$dias = 1; 
} 
/* 
Calcular total 
*/ 
$total = 
$dias * 
$r['valor_diaria']; 
/* 
Finalizar reserva 
*/ 
$stmt = 
$conn->prepare( 
"UPDATE reserva 
SET status='Finalizada' 
WHERE id_reserva=?" 
); 
$stmt->bind_param( 
"i", 
$id 
); 
$stmt->execute(); 
/* 
Liberar quarto 
*/ 
$stmt = 
$conn->prepare( 
"UPDATE quarto 
SET status='Disponível' 
WHERE id_quarto=?" 
); 
$stmt->bind_param( 
"i", 
$r['id_quarto'] 
); 
$stmt->execute(); 
?> 
<h1>Check-out realizado</h1> 
<p> 
Quarto: 
<strong> 
<?= $r['numero'] ?> 
</strong> 
</p> 
<p> 
Quantidade de diárias: 
<strong> 
<?= $dias ?> 
</strong> 
</p> 
<p> 
Valor da diária: 
<strong> 
R$ 
<?= number_format( 
$r['valor_diaria'], 
2, 
',', 
'.' 
) ?> 
</strong> 
</p> 
<h2> 
Total: 
R$ 
<?= number_format( 
$total, 
2, 
',', 
'.' 
) ?> 
</h2> 
<a href="dashboard.php"> 
Voltar ao Dashboard 
</a>