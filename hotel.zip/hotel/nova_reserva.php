<?php 
require "verifica_login.php"; 
require "conexao.php"; 
$hospedes = 
$conn->query( 
"SELECT * 
FROM hospede 
ORDER BY nome" 
); 
$quartos = 
$conn->query( 
"SELECT * 
FROM quarto 
WHERE status='Disponível' 
ORDER BY numero" 
); 
?> 
<h2>Nova reserva</h2> 
<form 
action="salvar_reserva.php" 
method="POST"> 
Hóspede: 
<select name="hospede"> 
<?php 
while( 
$h = 
$hospedes->fetch_assoc() 
){ 
?> 
<option 
value="<?= $h['id_hospede'] ?>"> 
<?= htmlspecialchars($h['nome']) ?> 
</option> 
<?php } ?> 
</select> 
<br><br> 
Quarto: 
<select name="quarto"> 
<?php 
while( 
$q = 
$quartos->fetch_assoc() 
){ 
?> 
<option 
value="<?= $q['id_quarto'] ?>"> 
Quarto 
<?= htmlspecialchars($q['numero']) ?> - 
<?= htmlspecialchars($q['tipo']) ?> 
</option> 
<?php } ?> 
</select> 
<br><br>

Entrada: 
<input 
type="date" 
name="entrada" 
required> 
<br><br> 
Saída: 
<input 
type="date" 
name="saida" 
required> 
<br><br> 
<button> 
Realizar reserva 
</button> 
</form>