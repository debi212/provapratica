<?php
require "conexao.php";

$sql = "SELECT * FROM alunos";
$stmt = $pdo->query($sql);
$alunos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Alunos</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<h1>Lista de Alunos</h1>

<a href="cadastrar.php">Cadastrar aluno</a>

<table border="1">

<tr>
    <th>ID</th>
    <th>Nome</th>
    <th>Email</th>
    <th>Idade</th>
    <th>Ações</th>
</tr>

<?php foreach ($alunos as $aluno): ?>

<tr>

    <td><?= $aluno['id'] ?></td>

    <td><?= $aluno['nome'] ?></td>

    <td><?= $aluno['email'] ?></td>

    <td><?= $aluno['idade'] ?></td>

    <td>
        <a href="editar.php?id=<?= $aluno['id'] ?>">Editar</a>

        <a href="excluir.php?id=<?= $aluno['id'] ?>">Excluir</a>
    </td>

</tr>

<?php endforeach; ?>

</table>

</body>
</html>