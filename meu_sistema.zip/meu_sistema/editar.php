<?php

require "conexao.php";

$id = $_GET["id"];

$sql = "SELECT * FROM alunos WHERE id = ?";

$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);

$aluno = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $idade = $_POST["idade"];

    $sql = "UPDATE alunos
            SET nome = ?, email = ?, idade = ?
            WHERE id = ?";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        $nome,
        $email,
        $idade,
        $id
    ]);

    header("Location: index.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Editar</title>
</head>

<body>

<h1>Editar aluno</h1>

<form method="POST">

    <label>Nome:</label>

    <input
        type="text"
        name="nome"
        value="<?= $aluno['nome'] ?>"
        required
    >

    <br><br>

    <label>Email:</label>

    <input
        type="email"
        name="email"
        value="<?= $aluno['email'] ?>"
        required
    >

    <br><br>

    <label>Idade:</label>

    <input
        type="number"
        name="idade"
        value="<?= $aluno['idade'] ?>"
        required
    >

    <br><br>

    <button type="submit">Salvar alterações</button>

</form>

</body>
</html>