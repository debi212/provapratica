<?php
include 'conecta.php';

if (!isset($_GET['id'])) {
    die("ID n�o informado.");
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("DELETE FROM livros WHERE id_livro = ?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: index.php");
exit;
?>
