<?php
include 'conecta.php';

$sql = "SELECT
            livros.id_livro,
            livros.titulo,
            autores.nome AS autor,
            livros.editora,
            livros.ano_publicacao,
            livros.paginas
        FROM livros
        INNER JOIN autores
            ON livros.id_autor = autores.id_autor
        ORDER BY livros.titulo";

$res = $con->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Lista de Livros</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1>Lista de Livros</h1>

    <nav>
        <a href="autores.php">Autores</a>
        <a href="form_livro.php">Novo Livro</a>
    </nav>

    <table>
        <tr>
            <th>ID</th>
            <th>T�tulo</th>
            <th>Autor</th>
            <th>Editora</th>
            <th>Ano</th>
            <th>P�ginas</th>
            <th>A��es</th>
        </tr>

        <?php while ($row = $res->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id_livro'] ?></td>
            <td><?= htmlspecialchars($row['titulo']) ?></td>
            <td><?= htmlspecialchars($row['autor']) ?></td>
            <td><?= htmlspecialchars($row['editora']) ?></td>
            <td><?= $row['ano_publicacao'] ?></td>
            <td><?= $row['paginas'] ?></td>
            <td>
                <a href="form_livro.php?id=<?= $row['id_livro'] ?>">Editar</a>
                <a href="excluir_livro.php?id=<?= $row['id_livro'] ?>"
                   onclick="return confirm('Deseja excluir este livro?')">
                   Excluir
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
