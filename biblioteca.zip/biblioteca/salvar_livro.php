<?php
include 'conecta.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Acesso inv�lido.");
}

$id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
$titulo = trim($_POST['titulo']);
$id_autor = (int) $_POST['id_autor'];
$editora = trim($_POST['editora']);
$ano = (int) $_POST['ano'];
$paginas = (int) $_POST['paginas'];

if ($titulo === '' || $id_autor <= 0 || $editora === '' ||
    $ano < 1000 || $ano > 9999 || $paginas <= 0) {
    die("Dados inv�lidos.");
}

if ($id > 0) {
    $stmt = $con->prepare(
        "UPDATE livros
         SET titulo=?, id_autor=?, editora=?, ano_publicacao=?, paginas=?
         WHERE id_livro=?"
    );
    $stmt->bind_param("sisiii",
        $titulo, $id_autor, $editora, $ano, $paginas, $id);
} else {
    $stmt = $con->prepare(
        "INSERT INTO livros
         (titulo, id_autor, editora, ano_publicacao, paginas)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("sisii",
        $titulo, $id_autor, $editora, $ano, $paginas);
}

$stmt->execute();

header("Location: index.php");
exit;
?>
