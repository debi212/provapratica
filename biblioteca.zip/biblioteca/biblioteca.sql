CREATE DATABASE biblioteca
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE biblioteca;

CREATE TABLE autores (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

CREATE TABLE livros (
    id_livro INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    id_autor INT NOT NULL,
    editora VARCHAR(100) NOT NULL,
    ano_publicacao YEAR NOT NULL,
    paginas INT NOT NULL,
    FOREIGN KEY (id_autor)
        REFERENCES autores(id_autor)
        ON DELETE CASCADE
);
