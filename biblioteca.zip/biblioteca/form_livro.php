<?php
include 'conecta.php';

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$titulo = '';
$id_autor = '';
$editora = '';
$ano_publicacao = '';
$paginas = '';

if ($id > 0) {
    $stmt = $con->prepare("SELECT * FROM livros WHERE id_livro = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $livro = $stmt->get_result()->fetch_assoc();

    if ($livro) {
        $titulo = $livro['titulo'];
        $id_autor = $livro['id_autor'];
        $editora = $livro['editora'];
        $ano_publicacao = $livro['ano_publicacao'];
        $paginas = $livro['paginas'];
    }
}

$autores = $con->query("SELECT * FROM autores ORDER BY nome");
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Livro</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">
    <h1><?= $id > 0 ? 'Editar Livro' : 'Cadastrar Livro' ?></h1>

    <form id="form_livro" method="post" action="salvar_livro.php">
        <input type="hidden" name="id" value="<?= $id ?>">

        <label>T�tulo:</label>
        <input type="text" id="titulo" name="titulo"
               value="<?= htmlspecialchars($titulo) ?>" required>

        <label>Autor:</label>
        <select id="id_autor" name="id_autor" required>
            <option value="">Selecione</option>
            <?php while ($a = $autores->fetch_assoc()): ?>
                <option value="<?= $a['id_autor'] ?>"
                    <?= $id_autor == $a['id_autor'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($a['nome']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <label>Editora:</label>
        <input type="text" id="editora" name="editora"
               value="<?= htmlspecialchars($editora) ?>" required>

        <label>Ano de publica��o:</label>
        <input type="number" id="ano" name="ano"
               min="1000" max="9999"
               value="<?= htmlspecialchars($ano_publicacao) ?>" required>

        <label>Quantidade de p�ginas:</label>
        <input type="number" id="paginas" name="paginas"
               min="1" value="<?= htmlspecialchars($paginas) ?>" required>

        <button type="submit">Salvar</button>
        <a href="index.php" class="botao">Voltar</a>
    </form>
</div>

<script src="js/validar.js"></script>
</body>
</html>
